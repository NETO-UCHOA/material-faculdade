package com.example.autenticacao;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AutenticacaoApplicationTests {

	@Test
	void contextLoads() {
	}

}
