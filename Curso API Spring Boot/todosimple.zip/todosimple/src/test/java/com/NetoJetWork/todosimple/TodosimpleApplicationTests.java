package com.NetoJetWork.todosimple;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TodosimpleApplicationTests {

	@Test
	void contextLoads() {
	}

}
