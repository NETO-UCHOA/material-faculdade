package com.livraria.app.interfaces;

public interface Produto {
    
    public void aplicarDesconto(double porcentagem);

}
