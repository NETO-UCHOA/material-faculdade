package com.taskify.api.constants;

public enum Genero {
    MASCULINO,
    FEMININO
}
