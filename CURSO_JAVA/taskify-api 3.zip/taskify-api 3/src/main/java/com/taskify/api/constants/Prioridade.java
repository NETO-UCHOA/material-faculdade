package com.taskify.api.constants;

public enum Prioridade {
    ALTA,
    MEDIA,
    BAIXA
}
