package com.taskify.api.constants;

public enum Situacao {
    PENDENTE,
    EM_ANDAMENTO,
    CONCLUIDA
}
