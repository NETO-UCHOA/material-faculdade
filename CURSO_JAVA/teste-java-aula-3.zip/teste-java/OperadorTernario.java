public class OperadorTernario {

    public static void main(String[] args) {
        int idade = 19;

        double valorIngresso = (idade < 18) ? 200 : 400;

        System.out.println("Valor do ingresso: " + valorIngresso);
    }
    
}
